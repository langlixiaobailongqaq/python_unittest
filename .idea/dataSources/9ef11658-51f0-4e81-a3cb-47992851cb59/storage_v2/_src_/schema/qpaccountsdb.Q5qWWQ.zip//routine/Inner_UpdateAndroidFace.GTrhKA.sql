create
  definer = QYGame@`%` procedure Inner_UpdateAndroidFace()
BEGIN
		DECLARE dwUserID int;
		DECLARE dwIndex int;
		DECLARE doneUserID INT DEFAULT false;
		DECLARE curUserID CURSOR FOR SELECT UserID from AccountsInfo where IsAndroid=1;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET doneUserID = true;

		update qpaccountsdb.AccountsInfo set FaceID=1+RAND()%11 where IsAndroid=1;

		set dwIndex=1;
		-- 插入其它渠道数据
		OPEN curUserID;
		FETCH curUserID INTO dwUserID;  
		WHILE(NOT doneUserID)
		DO
				update AccountsInfo set WXHeadURL=CONCAT('https://kx.yingxiongbb.cn/Face/face',dwIndex,'.jpg') where UserID=dwUserID;
				FETCH curUserID INTO dwUserID;  
				set dwIndex=dwIndex+1;
		END WHILE;
		CLOSE curUserID;
END;

