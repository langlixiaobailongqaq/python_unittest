create
  definer = QYGame@`%` procedure NET_PM_AddAccountWXLimit(IN dwSpreaderID int, IN strAccounts varchar(40),
                                                          IN strNickName varchar(31), IN strLogonPass char(32),
                                                          IN strInsurePass char(32), IN dwFaceID int,
                                                          IN strUnderWrite varchar(18), IN strPassPortID varchar(18),
                                                          IN strCompellation varchar(16), IN dwExperience int,
                                                          IN dwPresent int, IN dwLoveLiness int, IN dwUserRight int,
                                                          IN dwMasterRight int, IN dwServiceRight int,
                                                          IN dwMasterOrder tinyint, IN dwMemberOrder tinyint,
                                                          IN dtMemberOverDate datetime, IN dtMemberSwitchDate datetime,
                                                          IN dwGender tinyint, IN dwNullity tinyint,
                                                          IN dwStunDown tinyint, IN dwMoorMachine tinyint,
                                                          IN strRegisterIP varchar(15),
                                                          IN strRegisterMachine varchar(32), IN IsAndroid tinyint,
                                                          IN strQQ varchar(16), IN strEMail varchar(32),
                                                          IN strSeatPhone varchar(32), IN strMobilePhone varchar(16),
                                                          IN strDwellingPlace varchar(128), IN strPostalCode varchar(8),
                                                          IN strUserNote varchar(256), IN wxHeadUrl varchar(256),
                                                          IN gameLogin tinyint, IN webLogin tinyint,
                                                          IN channelID varchar(50), IN channelCode varchar(50),
                                                          OUT errCode int)
LB_Begin:BEGIN
	DECLARE dtCurrentDate datetime;
	-- DECLARE startDate datetime;
	-- DECLARE dtNoviceExpiryDate datetime;
	DECLARE RegistCount int;
	DECLARE RegistCounted int;
	DECLARE DateID int;
	DECLARE GrantScoreCount int;
	DECLARE GrantAwardCount int;
	DECLARE dwUserID int;
	DECLARE dwGameID int;

	SET dtCurrentDate = curdate();
  -- SET startDate=DATE_ADD(dtCurrentDate, interval 7 DAY);
  -- SET dtNoviceExpiryDate=DATE_ADD(CONVERT(startDate, DATETIME), interval -1 second);
	SET errCode=-1;

	IF strAccounts IS NULL OR strAccounts = '' then
		set errCode=-2;	
		select errCode;
		LEAVE LB_Begin;   
	END if;

	IF strNickName IS NULL OR 	strNickName = '' then
		SET strNickName = strAccounts;
	end if;
	IF strInsurePass IS NULL OR strInsurePass = '' then 
		SET strInsurePass = strLogonPass;
	end if;

	IF char_length(strMobilePhone)>1 then
		SELECT SystemStatusInfo.StatusValue into RegistCount FROM SystemStatusInfo WHERE StatusName='RegisterCallCount';
		IF RegistCount IS NULL OR RegistCount = '' then
			  set RegistCount=0;
		end if;
		select COUNT(*) into RegistCounted from AccountsInfo where AccountsInfo.RegisterMobile=strMobilePhone;
		if RegistCount<=RegistCounted then
			set errCode=-8;	
			select errCode;
			LEAVE LB_Begin;
		END if;
	END if;

	SET DateID=TO_DAYS(curdate());
	SELECT StatusValue into GrantScoreCount FROM SystemStatusInfo WHERE StatusName='GrantScoreCount';
	SELECT StatusValue into GrantAwardCount FROM SystemStatusInfo WHERE StatusName='GrantAwardCount';
	IF GrantScoreCount IS NULL OR GrantScoreCount = '' OR GrantScoreCount <= 0 then
		SET GrantScoreCount = 0;
	end if;
	IF GrantAwardCount IS NULL OR GrantAwardCount = '' OR GrantAwardCount <= 0 then
		SET GrantAwardCount = 0;
	end if;
	
	set dtCurrentDate = NOW();
	start transaction;
	INSERT AccountsInfo
				( Accounts,NickName,RegAccounts,UnderWrite,PassPortID,
				  Compellation ,LogonPass ,InsurePass ,FaceID,Experience ,
				  Present,LoveLiness,UserRight ,MasterRight ,ServiceRight ,
				  MasterOrder ,MemberOrder ,MemberOverDate ,MemberSwitchDate ,Gender ,
				  Nullity ,NullityOverDate,StunDown ,MoorMachine ,LastLogonIP,LastLogonMobile,RegisterIP ,
				  RegisterDate ,RegisterMobile ,RegisterMachine ,IsAndroid,SpreaderID,WXHeadURL,
					GameLogonTimes,WebLogonTimes,ChannelID,Ticket,ChannelCode
				)
		VALUES  (				  			  
				  strAccounts , -- Accounts - nvarchar(31)
				  strNickName , -- NickName - nvarchar(31)
				  strAccounts , -- RegAccounts - nvarchar(31)	
				  strUnderWrite,			  
				  strPassPortID , -- PassPortID - nvarchar(18)
				  
				  strCompellation , -- Compellation - nvarchar(16)
				  strLogonPass , -- LogonPass - nchar(32)
				  strInsurePass , -- InsurePass - nchar(32)
				  dwFaceID,
				  dwExperience , -- Experience - int
				  
				  dwPresent,							
				  dwLoveLiness,
				  dwUserRight , -- UserRight - int
				  dwMasterRight , -- MasterRight - int
				  dwServiceRight , -- ServiceRight - int
				  
				  dwMasterOrder , -- MasterOrder - tinyint
				  dwMemberOrder , -- MemberOrder - tinyint
				  dtMemberOverDate , -- MemberOverDate - datetime
				  dtMemberSwitchDate , -- MemberSwitchDate - datetime
				  dwGender , -- Gender - tinyint
				  
				  dwNullity, -- Nullity - tinyint
					'1900-01-01 00:00:00',
				  dwStunDown , -- StunDown - tinyint
				  dwMoorMachine , -- MoorMachine - tinyint	  
				  strRegisterIP,      
					'',
				  strRegisterIP , -- RegisterIP - nvarchar(15)
				  
				  dtCurrentDate , -- RegisterDate - datetime
				  strMobilePhone , -- RegisterMobile - nvarchar(11)
				  strRegisterMachine , -- RegisterMachine - nvarchar(32)
				  IsAndroid , -- IsAndroid - tinyint	
				  dwSpreaderID	,
				  wxHeadUrl ,
				  gameLogin,
				  webLogin,
				  channelID,
				  GrantAwardCount,
				  channelCode
				);
	SET dwUserID  = LAST_INSERT_ID();
	
	INSERT IndividualDatum
						( UserID ,Compellation ,QQ ,EMail ,SeatPhone ,
						  MobilePhone ,DwellingPlace ,PostalCode ,CollectDate ,UserNote
						)
	VALUES  ( dwUserID , -- UserID - int
						  strCompellation , -- Compellation - nvarchar(16)
						  strQQ , -- QQ - nvarchar(16)
						  strEMail , -- EMail - nvarchar(32)
						  strSeatPhone , -- SeatPhone - nvarchar(32)
						  strMobilePhone , -- MobilePhone - nvarchar(16)
						  strDwellingPlace , -- DwellingPlace - nvarchar(128)
						  strPostalCode , -- PostalCode - nvarchar(8)
						  dtCurrentDate , -- CollectDate - datetime
						  strUserNote  -- UserNote - nvarchar(256)
						);
	INSERT qptreasuredb.GameScoreInfo
				        ( UserID ,	
				          Score,
				          Revenue,
				          InsureScore,		          
				          UserRight ,
				          MasterRight ,
				          MasterOrder ,
				          LastLogonMachine,				         
				          LastLogonIP ,				         
				          RegisterIP ,
				          RegisterDate,
				          RegisterMachine
				           
				        )
	VALUES  ( dwUserID , -- UserID - int
				          GrantScoreCount , -- Score - bigint
				          0 , -- Revenue - bigint
				          0 , -- InsureScore - bigint				        
				          dwUserRight , -- UserRight - int
				          dwMasterRight , -- MasterRight - int
				          dwMasterOrder , -- MasterOrder - tinyint	
				          '',			          
				          strRegisterIP , -- LastLogonIP - nvarchar(15)
				          strRegisterIP , -- RegisterIP - nvarchar(15)
				          dtCurrentDate,  -- RegisterDate - datetime
				          ''				          				         
				        );   

	SELECT GameIdentifier.GameID into dwGameID FROM GameIdentifier WHERE GameIdentifier.UserID=dwUserID;
	IF dwGameID IS NULL then
		set errCode=1;	
	else
		UPDATE AccountsInfo SET AccountsInfo.GameID=dwGameID WHERE AccountsInfo.UserID=dwUserID;
		set errCode=0;	
	end if;

	commit;	
	
	if errCode=1 or errCode=0 then
		UPDATE SystemStreamInfo SET SystemStreamInfo.WebRegisterSuccess=SystemStreamInfo.WebRegisterSuccess+1 WHERE SystemStreamInfo.DateID=DateID;
		IF row_count()=0 THEN
			INSERT SystemStreamInfo(SystemStreamInfo.DateID, SystemStreamInfo.WebRegisterSuccess) VALUES (DateID, 1);
		end if;
		
		IF GrantScoreCount > 0 THEN
			UPDATE SystemGrantCount SET SystemGrantCount.GrantScore=SystemGrantCount.GrantScore+GrantScoreCount, 
			SystemGrantCount.GrantCount=SystemGrantCount.GrantCount+1 WHERE SystemGrantCount.DateID=DateID AND SystemGrantCount.RegisterIP=strRegisterIP;

			IF row_count()=0	THEN
				INSERT SystemGrantCount (SystemGrantCount.DateID, SystemGrantCount.RegisterIP, SystemGrantCount.RegisterMachine, SystemGrantCount.GrantScore, SystemGrantCount.GrantCount) 
				VALUES (DateID, strRegisterIP, '', GrantScoreCount, 1);
			end if;
		END if;
	end if;
	
	select errCode;
END;

