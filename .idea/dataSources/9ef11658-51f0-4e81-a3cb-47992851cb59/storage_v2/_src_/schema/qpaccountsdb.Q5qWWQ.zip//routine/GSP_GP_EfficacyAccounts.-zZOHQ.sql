create
  definer = QYGame@`112.17.125.245` procedure GSP_GP_EfficacyAccounts(IN strAccounts varchar(40),
                                                                      IN strPassword char(32),
                                                                      IN strClientIP varchar(15),
                                                                      IN strMachineID varchar(32), OUT errCode int,
                                                                      OUT strErrorDescribe varchar(127))
LB_Begin:BEGIN
	DECLARE EnjoinLogon int;
	DECLARE StatusString varchar(512);
	DECLARE UserID int;
	DECLARE GameID int;
	DECLARE Ticket bigint;
	DECLARE Accounts VARCHAR(40);
	DECLARE NickName VARCHAR(31);
	DECLARE PassPortID VARCHAR(18);
	DECLARE UnderWrite VARCHAR(250);
	DECLARE LogonPass VARCHAR(32);
	DECLARE FaceID int;
	DECLARE Gender TINYINT;
	DECLARE Nullity TINYINT;
	DECLARE StunDown TINYINT;
	DECLARE UserMedal int;
	DECLARE Experience int;
	DECLARE LoveLiness int;
	DECLARE MemberOrder TINYINT;
	DECLARE MemberOverDate datetime;
	DECLARE MemberSwitchDate datetime;
	DECLARE MoorMachine TINYINT;
	DECLARE MachineSerial VARCHAR(40);
	DECLARE SpreaderID int;
	DECLARE PlayTimeCount bigint;
	DECLARE Score bigint;
	DECLARE Insure bigint;
	DECLARE UserRight int;
	DECLARE DateID int;
	DECLARE KindID int;
	DECLARE ServerID int;
	DECLARE VIP	tinyint;
	DECLARE CustomID int;

	-- 系统暂停
	SELECT SystemStatusInfo.StatusValue,SystemStatusInfo.StatusString into EnjoinLogon,StatusString FROM SystemStatusInfo WHERE SystemStatusInfo.StatusName='EnjoinLogon';
	IF EnjoinLogon IS NOT NULL AND EnjoinLogon<>0 then
		set strErrorDescribe=StatusString;
		set errCode=2;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
	END if;

	-- 效验地址
	SELECT ConfineAddress.EnjoinLogon into EnjoinLogon FROM ConfineAddress WHERE ConfineAddress.AddrString=strClientIP AND (ConfineAddress.EnjoinOverDate>NOW() OR ConfineAddress.EnjoinOverDate IS NULL);
	IF EnjoinLogon IS NOT NULL AND EnjoinLogon<>0 then
		SET strErrorDescribe='抱歉地通知您，系统禁止了您所在的 IP 地址的登录功能，请联系客户服务中心了解详细情况！';
		set errCode=4;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
	END if;

	-- 效验机器
	SELECT ConfineMachine.EnjoinLogon into EnjoinLogon FROM ConfineMachine WHERE ConfineMachine.MachineSerial=strMachineID AND (ConfineMachine.EnjoinOverDate>NOW() OR ConfineMachine.EnjoinOverDate IS NULL);
	IF EnjoinLogon IS NOT NULL AND EnjoinLogon<>0 then
		SET strErrorDescribe='抱歉地通知您，系统禁止了您的机器的登录功能，请联系客户服务中心了解详细情况！';
		set errCode=7;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
	END if;

	-- 查询用户
	SELECT AccountsInfo.UserID, AccountsInfo.GameID,AccountsInfo.Ticket, AccountsInfo.Accounts, AccountsInfo.NickName,AccountsInfo.PassPortID,
		AccountsInfo.UnderWrite, AccountsInfo.LogonPass,AccountsInfo.FaceID, AccountsInfo.Gender, AccountsInfo.Nullity, 
		AccountsInfo.StunDown, AccountsInfo.UserMedal, AccountsInfo.Experience,AccountsInfo.LoveLiness, AccountsInfo.MemberOrder, AccountsInfo.MemberOverDate, 
		AccountsInfo.MemberSwitchDate,AccountsInfo.MoorMachine, AccountsInfo.LastLogonMachine,AccountsInfo.SpreaderID,AccountsInfo.PlayTimeCount, AccountsInfo.VIP,
		AccountsInfo.CustomID
		into UserID,GameID,Ticket,Accounts,NickName,PassPortID,UnderWrite,LogonPass,FaceID,Gender,Nullity,StunDown,UserMedal,
		Experience,LoveLiness,MemberOrder,MemberOverDate,MemberSwitchDate,MoorMachine,MachineSerial,SpreaderID,PlayTimeCount,VIP,CustomID
	FROM AccountsInfo WHERE AccountsInfo.Accounts=strAccounts;

	-- 查询用户
	IF UserID IS NULL then
		SET strErrorDescribe='您的帐号不存在或者密码输入有误，请查证后再次尝试登录！';
		set errCode=1;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
	END	if;

	-- 帐号禁止
	IF Nullity<>0 then
		SET strErrorDescribe=CONCAT('您的游戏ID[',GameID,']暂时处于冻结状态，请联系客户服务中心了解详细情况！');
		set errCode=2;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
	END	if;

	-- 帐号关闭
	IF StunDown<>0 then
		SET strErrorDescribe='您的帐号使用了安全关闭功能，必须重新开通后才能继续使用！';
		set errCode=2;
		LEAVE LB_Begin;
	END	if;
	
	-- 固定机器
	IF MachineSerial<>strMachineID and MoorMachine=1 then
		SET strErrorDescribe='您的帐号使用固定机器登录功能，您现所使用的机器不是所指定的机器！';
		set errCode=1;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
  END if;

	-- 密码判断
	IF LogonPass<>strPassword then
		SET strErrorDescribe='您的帐号不存在或者密码输入有误，请查证后再次尝试登录！';
		set errCode=3;
		select errCode,strErrorDescribe;
		LEAVE LB_Begin;
	END if;

	-- 查询金币
	SELECT qptreasuredb.GameScoreInfo.Score, qptreasuredb.GameScoreInfo.InsureScore into Score,Insure FROM qptreasuredb.GameScoreInfo WHERE qptreasuredb.GameScoreInfo.UserID=UserID;

	-- 数据调整
	IF Score IS NULL THEN
		SET Score=0;
	end if;
	IF Insure IS NULL THEN
		SET Insure=0;
	end if;

	-- 会员等级
	IF MemberOrder<>0 AND NOW()>MemberSwitchDate then
		SET UserRight=0;
		
		-- 删除会员
		DELETE from AccountsMember WHERE AccountsMember.UserID=UserID AND AccountsMember.MemberOverDate<=NOW();

		-- 搜索会员
		SELECT MAX(AccountsMember.MemberOverDate), MAX(AccountsMember.MemberOrder), MIN(AccountsMember.MemberOverDate) into 
			MemberOverDate,MemberOrder,MemberSwitchDate 
			FROM AccountsMember WHERE AccountsMember.UserID=UserID;
	
		-- 数据调整
		IF MemberOrder IS NULL then
			SET MemberOrder=0;
			SET UserRight=512;
		END if;
		IF MemberOverDate IS NULL THEN
			SET MemberOverDate='1980-1-1';
		end if;

		IF MemberSwitchDate IS NULL then 
			SET MemberSwitchDate='1980-1-1';
		end if;

		-- 更新数据
		UPDATE AccountsInfo SET AccountsInfo.MemberOrder=MemberOrder, AccountsInfo.MemberOverDate=MemberOverDate, AccountsInfo.MemberSwitchDate=MemberSwitchDate,
			AccountsInfo.UserRight=UserRight&~UserRight WHERE AccountsInfo.UserID=UserID;
	END if;

	-- 更新信息
	SELECT qptreasuredb.GameScoreLocker.KindID,qptreasuredb.GameScoreLocker.ServerID into KindID,ServerID FROM qptreasuredb.GameScoreLocker WHERE qptreasuredb.GameScoreLocker.UserID = UserID;
	
	-- 更新信息
	UPDATE AccountsInfo SET AccountsInfo.GameLogonTimes=AccountsInfo.GameLogonTimes+1,AccountsInfo.LastLogonDate=NOW(), AccountsInfo.LastLogonIP=strClientIP,
		AccountsInfo.LastLogonMachine=strMachineID WHERE AccountsInfo.UserID=UserID;

	-- 记录日志
	SET DateID=to_days(curdate());
	UPDATE SystemStreamInfo SET SystemStreamInfo.GameLogonSuccess=SystemStreamInfo.GameLogonSuccess+1 WHERE SystemStreamInfo.DateID=DateID;
	IF row_count()=0 THEN
		INSERT SystemStreamInfo(SystemStreamInfo.DateID, SystemStreamInfo.GameLogonSuccess) VALUES (DateID, 1);
	end if;
	
	set errCode=0;
	set strErrorDescribe='登录成功！';

	-- 输出变量
	select errCode,strErrorDescribe,FaceID,UserID, GameID, Accounts, NickName, UnderWrite, Gender, UserMedal, Experience,
		Score, Insure, LoveLiness, MemberOrder, MemberOverDate,MoorMachine,SpreaderID,KindID, ServerID,Ticket,VIP,CustomID;
END;

