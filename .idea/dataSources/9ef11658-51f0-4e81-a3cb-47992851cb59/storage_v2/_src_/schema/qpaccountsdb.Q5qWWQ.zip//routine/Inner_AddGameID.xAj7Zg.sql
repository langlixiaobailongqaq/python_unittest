create
  definer = QYGame@`%` procedure Inner_AddGameID(IN dwAddCount int)
BEGIN
	DECLARE i int;
	DECLARE dwStartUserID int;
	DECLARE dwStartGameID int;

	select UserID,GameID into dwStartUserID,dwStartGameID from GameIdentifier order by UserID DESC limit 1;
	set dwStartUserID=dwStartUserID+1;
	set dwStartGameID=dwStartGameID+1;

	set i = 0;
	WHILE i < dwAddCount DO
		select GameID from ReserveIdentifier where GameID=dwStartGameID;
		if FOUND_ROWS() = 0 then
				INSERT into GameIdentifier VALUES(dwStartUserID,dwStartGameID,0);
				set dwStartUserID = dwStartUserID+1;
				SET i = i + 1;
		end if;
		set dwStartGameID=dwStartGameID+1;
  END WHILE;
END;

