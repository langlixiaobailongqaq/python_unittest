create
  definer = QYGame@`%` procedure Inner_RemoveTableData()
BEGIN
		-- 清空数据表中数据
		truncate table AccountBackpack;
		TRUNCATE table SystemGrantCount;
		TRUNCATE table SystemStreamInfo;
END;

