create
  definer = QYGame@`%` procedure Inner_UserInfoDivide()
BEGIN
		select partition_name part from information_schema.partitions where table_schema = schema() and table_name='AccountsInfo';
		if ROW_COUNT() > 1 THEN
			ALTER TABLE AccountsInfo REMOVE PARTITIONING;
		end if;
		alter table AccountsInfo partition by HASH(userid) PARTITIONS 10 (
			PARTITION p0,  
      PARTITION p1,  
      PARTITION p2,  
      PARTITION p3,
			PARTITION p4,
			PARTITION p5,
			PARTITION p6,
			PARTITION p7,
			PARTITION p8,
			PARTITION p9);

		select partition_name part from information_schema.partitions where table_schema = schema() and table_name='IndividualDatum';
		if ROW_COUNT() > 1 THEN
			ALTER TABLE IndividualDatum REMOVE PARTITIONING;
		end if;
		alter table IndividualDatum partition by HASH(userid) PARTITIONS 10 (
			PARTITION p0,  
      PARTITION p1,  
      PARTITION p2,  
      PARTITION p3,
			PARTITION p4,
			PARTITION p5,
			PARTITION p6,
			PARTITION p7,
			PARTITION p8,
			PARTITION p9);
END;

