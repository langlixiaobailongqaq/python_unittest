create
  definer = QYGame@`%` procedure Inner_InsertData()
BEGIN
	DECLARE arrIndex int;
	set arrIndex = 1;
	WHILE arrIndex < 36 DO
			INSERT into SkiProbConfig(FishID,SkiPro,ServerID) VALUES(arrIndex,300,50);
		-- insert into TorProdConfig(FishID,MinGold,TorPro,WoodMaxCount,IronMaxCount,BronzeMaxCount,SilverMaxCount,GoldMaxCount,ServerID,ScoreRate) 
			-- VALUES(arrIndex,500000,30,40,100,100,200,9999999,50,80);
    SET arrIndex = arrIndex + 1;
  END WHILE;
END;

